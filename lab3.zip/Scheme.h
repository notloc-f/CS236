#ifndef SCHEME_H_
#define SCHEME_H_

class Schemes: public vector<string> {
public:
private:

};
#endif
