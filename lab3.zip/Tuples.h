#ifndef TUPLES_H_
#define TUPLES_H_

class Tuples: public vector<string> {
	public:
		
	private:

};
#endif
